#include <stdlib.h>

#include <stdio.h>

#include <time.h>

/* pour compiler ce fichier:  gcc –o cocotte cocotte.c libgraphique.c –lglut –lGLU –lGL –lm */
/* indispensable pour compiler un programme utilisant la bibliothèque graphique: */
#include "libgraphique.h"
//#include "libgraphique_fonts.h"
//#include "libgraphique.c"
#include <unistd.h>
//#include <stdio.h>
/*#ifdef __unix__
# include <unistd.h>
#elif defined _WIN32
# include <windows.h>
#define sleep(x) Sleep(1000 * x)
#endif*/
#define COTE_MIN (WINDOW_WIDTH < WINDOW_HEIGHT ? WINDOW_WIDTH : WINDOW_HEIGHT)
int main(void)
{
int coordo[1000];
int n,t,finli,finco,li,co,x1,y1,x2,y2,x;
int i,m,xn1,yn1,xn2,yn2,xm1,ym1,xm2,ym2;
char rep[100];
printf("entrez le nom du fichier à ouvrir:  ");
scanf("%s",rep);
FILE* fic=fopen(rep,"r");
start_graphics();
set_drawing_color(color_BLACK);
fscanf(fic,"%d %d %d %d",&n,&t,&finli,&finco);
m=n;
//calcul pour centrer la grille
int marge_c=(WINDOW_WIDTH-(t*n))/2;
int marge_h=(WINDOW_HEIGHT-(t*m))/2;
xn1=marge_c;
yn1=marge_h;
xm1=marge_c;
ym1=marge_h;
draw_rectangle(xn1+n,yn1,finli,finco);
update_graphics();
li=xn1+(t/2);
co=yn1-(1.5*t);
int fin1=xm1-(1.5*t);
int fin2=ym1+(t/2);
int r=t/6;
draw_circle_full(li,co,r); //création du curseur
update_graphics();
while((li<=fin1)&&(co>=fin2))
{
int touche=get_key();
//printf("%d",touche); mouchar pour vérifier que le rand marchait bien
    if(((touche==key_LEFT)&&(li>(xn1+(t/2)))))
    {   
	fscanf(fic,"%d %d %d %d",&x1,&y1,&x2,&y2);
	if(((li-(t/2))==x1)&&(co-(t/2)==y1))
	{	li=li-t;
        	draw_circle_full(li,co,r);
		set_drawing_color(color_WHITE);
        	draw_circle_full(li+t,co,r);
		draw_line(x1,y1,x2,y2);
        	set_drawing_color(color_BLACK);
	}
    }
    else if(((touche==key_RIGHT)&&(li<xn2-(t/2))))
    {   
	fscanf(fic,"%d %d %d %d",&x1,&y1,&x2,&y2);
	if(((li+(t/2))==x1)&&(co-(t/2)==y1))
	{	li=li+t;
        	draw_circle_full(li,co,r);
		set_drawing_color(color_WHITE);
        	draw_circle_full(li+t,co,r);
		draw_line(x1,y1,x2,y2);
        	set_drawing_color(color_BLACK);

	}
    }
    else if(((touche==key_DOWN)&&(co>fin2)))
    {   
	fscanf(fic,"%d %d %d %d",&x1,&y1,&x2,&y2);
	if(((li-(t/2))==x1)&&(co-(t/2)==y1))
	{	co=co-t;
        	draw_circle_full(li,co,r);
		set_drawing_color(color_WHITE);
        	draw_circle_full(li+t,co,r);
		draw_line(x1,y1,x2,y2);
        	set_drawing_color(color_BLACK);

	}
    }
    else if(((touche==key_UP)&&(co<yn1-(1.5*t))))
    {   
	fscanf(fic,"%d %d %d %d",&x1,&y1,&x2,&y2);
	if(((li-(t/2))==x1)&&(co+(t/2)==y1))
	{	co=co+t;
        	draw_circle_full(li,co,r);
		set_drawing_color(color_WHITE);
        	draw_circle_full(li+t,co,r);
		draw_line(x1,y1,x2,y2);
        	set_drawing_color(color_BLACK);

	}
    }
    else if (((li==fin1)&& (co==fin2)))
    {   li=li+t;
        draw_circle_full(li,co,r);
      	fscanf(fic,"%d %d",&x1,&y1);
	if(((li+(t/2))==finli)&&(co-(t/2)==finco))
	{	set_drawing_color(color_WHITE);
        	draw_circle_full(li+t,co,r);
		draw_line(x1,y1,finli,finco);
        	set_drawing_color(color_BLACK);

	}
	fclose(fic);
        sleep(5);
        stop_graphics();
    }
   update_graphics();
}
get_key();
return 0;
}

